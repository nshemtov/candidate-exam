package com.cyberark.test.items.services;

import com.cyberark.items.entities.ItemRuleType;
import com.cyberark.items.entities.ItemType;
import com.cyberark.items.entities.rules.*;
import com.cyberark.items.services.RuleHandler;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.HashMap;
import java.util.Map;

class RuleHandlerTest {

    Map<ItemRuleType, ItemRule> rulesConfigMap;
    Map<ItemType, ItemRule> itemTypeRuleMap;

    @BeforeEach
    void initMaps() {
        rulesConfigMap = new HashMap();
        rulesConfigMap.put(ItemRuleType.FIXED_VALUE, new FixedValue());
        rulesConfigMap.put(ItemRuleType.GAINS_VALUE_WITH_AGE, new GainsValueWithAge());
        rulesConfigMap.put(ItemRuleType.LOSES_CONSTANT_PERCENT_WITH_AGE, new LosesConstantPercentWithAge());
        rulesConfigMap.put(ItemRuleType.LOSES_CONSTANT_VALUE_WITH_AGE, new LosesConstantValueWithAge());
        rulesConfigMap.put(ItemRuleType.DEFAULT_RULE, new LosesConstantValueWithAge());

        itemTypeRuleMap = new HashMap<>();
        itemTypeRuleMap.put(ItemType.T_SHIRT, rulesConfigMap.get(ItemRuleType.FIXED_VALUE));
        itemTypeRuleMap.put(ItemType.BANANA, null);
    }

    @Test
    void getRulePerItemTypeTest() {
        RuleHandler ruleHandler = new RuleHandler(rulesConfigMap, itemTypeRuleMap);

        ItemRule rule = ruleHandler.getRule(ItemType.T_SHIRT);
        Assertions.assertTrue(rule instanceof FixedValue);
    }


    @Test
    void getDefaultRuleForNullReferenceTest() {
        RuleHandler ruleHandler = new RuleHandler(rulesConfigMap, itemTypeRuleMap);

        ItemRule rule = ruleHandler.getRule(ItemType.BANANA);
        Assertions.assertTrue(rule instanceof LosesConstantValueWithAge);
    }

    @Test
    void setItemTypeRuleTest() {
        RuleHandler ruleHandler = new RuleHandler(rulesConfigMap, itemTypeRuleMap);

        ruleHandler.setItemTypeRule(ItemType.BASKETBALL,ItemRuleType.GAINS_VALUE_WITH_AGE);
        Assertions.assertTrue(itemTypeRuleMap.get(ItemType.BASKETBALL) instanceof GainsValueWithAge);
    }
}