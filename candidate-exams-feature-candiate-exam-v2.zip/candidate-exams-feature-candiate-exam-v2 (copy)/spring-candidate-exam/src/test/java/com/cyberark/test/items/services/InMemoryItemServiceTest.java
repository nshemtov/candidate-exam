package com.cyberark.test.items.services;

import com.cyberark.items.entities.Item;
import com.cyberark.items.entities.ItemType;
import com.cyberark.items.entities.rules.GainsValueWithAge;
import com.cyberark.items.entities.rules.ItemRule;
import com.cyberark.items.entities.rules.LosesConstantValueWithAge;
import com.cyberark.items.repositories.ItemRepository;
import com.cyberark.items.services.InMemoryItemService;
import com.cyberark.items.services.RuleHandler;
import com.cyberark.test.TestApp;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.boot.test.context.ConfigFileApplicationContextInitializer;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import java.util.ArrayList;
import java.util.List;
import java.util.NoSuchElementException;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

@ExtendWith(SpringExtension.class)
@ExtendWith(MockitoExtension.class)
@ContextConfiguration(classes = {TestApp.class}, initializers = ConfigFileApplicationContextInitializer.class)
public class InMemoryItemServiceTest {

    @Test
    public void clearItemsTest() {
        ArrayList<Item> list1 = new ArrayList<>();
        list1.add(new Item(11, ItemType.T_SHIRT, 7, 10));
        list1.add(new Item(12, ItemType.LAPTOP, 5, 20));
        ItemRepository repo = new ItemRepository(list1);

        InMemoryItemService service = new InMemoryItemService(repo);
        service.clearItems();
        Assertions.assertTrue(service.getItems().isEmpty());
    }

    @Test
    public void getItemsTest() {
        ArrayList<Item> list1 = new ArrayList<>();
        list1.add(new Item(11, ItemType.T_SHIRT, 7, 10));
        list1.add(new Item(12, ItemType.LAPTOP, 5, 20));
        ItemRepository repo = new ItemRepository(list1);

        InMemoryItemService service = new InMemoryItemService(repo);
        List<Item> result = service.getItems();
        Assertions.assertTrue(result.equals(list1));
    }

    @Test
    public void getItemsEmptylistTest() {
        ArrayList<Item> list1 = new ArrayList<>();
        ItemRepository repo = new ItemRepository(list1);

        InMemoryItemService service = new InMemoryItemService(repo);
        List<Item> result = service.getItems();
        Assertions.assertTrue(result.isEmpty());
    }


    @Test
    public void getItemsNullListTest() {
        ItemRepository repo = new ItemRepository(null);

        InMemoryItemService service = new InMemoryItemService(repo);
        List<Item> result = service.getItems();
        Assertions.assertTrue(result == null);
    }

    @Test
    public void getItemTest() {
        ArrayList<Item> list1 = new ArrayList<>();
        Item item1 = new Item(11, ItemType.T_SHIRT, 7, 10);
        Item item2 =  new Item(12, ItemType.LAPTOP, 5, 20);
        list1.add(item1);
        list1.add(item2);
        ItemRepository repo = new ItemRepository(list1);

        InMemoryItemService service = new InMemoryItemService(repo);
        Item result = service.getItem(11);
        Assertions.assertTrue(result.equals(item1));
    }

    @Mock
    private RuleHandler ruleHandler;

    @Mock
    private ItemRepository itemRepository;

    @InjectMocks
    InMemoryItemService itemService;

    @Test
    public void dailyUpdateItemsTest(){
        ItemRule rule = new LosesConstantValueWithAge();
        when(ruleHandler.getRule(any())).thenReturn(rule);

        ArrayList<Item> list1 = new ArrayList<>();
        Item item1 = new Item(11, ItemType.T_SHIRT, 7, 10);
        list1.add(item1);
        when(itemRepository.getItems()).thenReturn(list1);

        itemService.dailyUpdateItems();

        Assertions.assertTrue(item1.getPrice()==9);
        Assertions.assertTrue(item1.getDaysToExpire()==6);
    }
}