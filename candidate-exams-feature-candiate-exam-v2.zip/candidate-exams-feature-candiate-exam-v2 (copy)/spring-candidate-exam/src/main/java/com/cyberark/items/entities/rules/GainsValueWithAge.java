package com.cyberark.items.entities.rules;

import com.cyberark.items.entities.Item;
import com.cyberark.items.entities.ItemRuleType;

public class GainsValueWithAge implements ItemRule {

    @Override
    public void apply(Item item) {
        item.setPrice(Math.min(1000, item.getPrice() + 1));
    }

    @Override
    public ItemRuleType getType() {
        return ItemRuleType.GAINS_VALUE_WITH_AGE;
    }
}
