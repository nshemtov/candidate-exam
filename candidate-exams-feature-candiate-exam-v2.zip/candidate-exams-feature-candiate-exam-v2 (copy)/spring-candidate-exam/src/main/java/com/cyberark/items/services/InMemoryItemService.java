package com.cyberark.items.services;

import com.cyberark.items.entities.rules.ItemRule;
import com.cyberark.items.entities.Item;
import com.cyberark.items.repositories.ItemRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.NoSuchElementException;

@Service
public class InMemoryItemService implements ItemService {

    @Autowired
    private ItemRepository itemRepository;

    @Autowired
    private RuleHandler ruleHandler;

    //used by tests
    public InMemoryItemService(ItemRepository itemRepository) {
        this.itemRepository = itemRepository;
    }

    @Override
    public void clearItems() {
        getItems().clear();
    }

    @Override
    public List<Item> getItems() {
        return itemRepository.getItems();
    }

    @Override
    public Item getItem(long id) {
        for (Item item : getItems()) {
            if (item.getId() == id){
                return item;
            }
        }
        throw new NoSuchElementException("item-id:"+id);
    }

    @Override
    public Item addItem(Item item) {
        getItems().add(item);
        return item;
    }

    @Override
    public void dailyUpdateItems() {
        for (Item item : getItems()) {
            ItemRule rule = ruleHandler.getRule(item.getType());
            rule.apply(item);
        }
    }
}