package com.cyberark.items.entities.rules;

import com.cyberark.items.entities.Item;
import com.cyberark.items.entities.ItemRuleType;

public interface ItemRule {

    void apply(Item item);

    ItemRuleType getType();
}
