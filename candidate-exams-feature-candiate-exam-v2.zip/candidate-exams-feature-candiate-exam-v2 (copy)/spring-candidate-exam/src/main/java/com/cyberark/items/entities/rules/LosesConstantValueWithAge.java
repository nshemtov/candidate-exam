package com.cyberark.items.entities.rules;

import com.cyberark.items.entities.Item;
import com.cyberark.items.entities.ItemRuleType;

public class LosesConstantValueWithAge implements ItemRule {
    @Override
    public void apply(Item item) {
        if (item.getDaysToExpire() > 0) {
            item.setPrice(item.getPrice() - 1);
            item.setDaysToExpire(item.getDaysToExpire() - 1);
        } else {
            item.setPrice(item.getPrice() - 2);
        }
    }

    @Override
    public ItemRuleType getType() {
        return ItemRuleType.LOSES_CONSTANT_VALUE_WITH_AGE;
    }
}
