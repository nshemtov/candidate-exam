package com.cyberark.items.entities.rules;

import com.cyberark.items.entities.Item;
import com.cyberark.items.entities.ItemRuleType;
import com.cyberark.items.entities.rules.ItemRule;

public class LosesConstantPercentWithAge implements ItemRule {
    @Override
    public void apply(Item item) {
        if (item.getDaysToExpire() > 0) {
            item.setPrice((int) (item.getPrice() * 0.95));
            item.setDaysToExpire(item.getDaysToExpire() - 1);
        } else {
            item.setPrice((int)(item.getPrice() * 0.9));
        }
    }

    @Override
    public ItemRuleType getType() {
        return ItemRuleType.LOSES_CONSTANT_PERCENT_WITH_AGE;
    }
}


