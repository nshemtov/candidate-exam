package com.cyberark.items.entities.rules;

import com.cyberark.items.entities.Item;
import com.cyberark.items.entities.ItemRuleType;

public class FixedValue implements ItemRule {

    @Override
    public void apply(Item item) {
        //do nothing
    }

    @Override
    public ItemRuleType getType() {
        return ItemRuleType.FIXED_VALUE;
    }
}
