package com.cyberark.items.entities;

public enum ItemType {
    SCOTCH_BOTTLE,
    BASKETBALL,
    BEER,
    T_SHIRT,
    BANANA,
    LAPTOP
}
