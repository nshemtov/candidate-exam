package com.cyberark.items.services;

import com.cyberark.items.entities.rules.*;
import com.cyberark.items.entities.ItemRuleType;
import com.cyberark.items.entities.ItemType;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.Map;

@Service
public class RuleHandler {

    private Map<ItemRuleType, ItemRule> rulesConfigMap;
    private Map<ItemType,ItemRule> itemTypeRuleMap;
    private final ItemRule defaultRule = new LosesConstantValueWithAge();

    public ItemRule getRule(ItemType itemType){
        ItemRule rule = itemTypeRuleMap.get(itemType);
        if (rule == null){
            rule = defaultRule;
        }
        return rule;
    }

    public void setItemTypeRule(ItemType itemType, ItemRuleType ruleType) {
        ItemRule rule = rulesConfigMap.get(ruleType);
        itemTypeRuleMap.put(itemType,rule);
    }

    RuleHandler() {
        System.out.println("empty constructor");
        loadRulesConfigMap();
        loadItemTypeRuleMap();
    }

    public RuleHandler(Map<ItemRuleType, ItemRule> rulesConfigMap, Map<ItemType, ItemRule> itemTypeRuleMap) {
        System.out.println("constructor with params");
        this.rulesConfigMap = rulesConfigMap;
        this.itemTypeRuleMap = itemTypeRuleMap;
    }

    //New rule implementation classes should be added here
    private void loadRulesConfigMap() {
        rulesConfigMap = new HashMap<>();
        rulesConfigMap.put(ItemRuleType.FIXED_VALUE,new FixedValue());
        rulesConfigMap.put(ItemRuleType.GAINS_VALUE_WITH_AGE,new GainsValueWithAge());
        rulesConfigMap.put(ItemRuleType.LOSES_CONSTANT_PERCENT_WITH_AGE,new LosesConstantPercentWithAge());
        rulesConfigMap.put(ItemRuleType.LOSES_CONSTANT_VALUE_WITH_AGE,new LosesConstantValueWithAge());
        rulesConfigMap.put(ItemRuleType.DEFAULT_RULE,new LosesConstantValueWithAge());
    }

    private void loadItemTypeRuleMap() {
        itemTypeRuleMap = new HashMap<>();
        itemTypeRuleMap.put(ItemType.T_SHIRT, rulesConfigMap.get(ItemRuleType.FIXED_VALUE));
        itemTypeRuleMap.put(ItemType.SCOTCH_BOTTLE, rulesConfigMap.get(ItemRuleType.GAINS_VALUE_WITH_AGE));
        itemTypeRuleMap.put(ItemType.BASKETBALL, rulesConfigMap.get(ItemRuleType.FIXED_VALUE));
        itemTypeRuleMap.put(ItemType.LAPTOP, rulesConfigMap.get(ItemRuleType.LOSES_CONSTANT_PERCENT_WITH_AGE));
        itemTypeRuleMap.put(ItemType.BANANA, null);
        itemTypeRuleMap.put(ItemType.BEER, null);
    }
}
