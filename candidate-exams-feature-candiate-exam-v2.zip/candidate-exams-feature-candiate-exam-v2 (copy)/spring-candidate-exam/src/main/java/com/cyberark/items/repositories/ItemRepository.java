package com.cyberark.items.repositories;

import com.cyberark.items.entities.Item;
import com.cyberark.items.entities.ItemType;
import org.springframework.stereotype.Repository;
import java.util.ArrayList;
import java.util.List;

@Repository
public class ItemRepository {

    private List<Item> items;

    public ItemRepository(){
        initItems();
    }

    //used by tests
    public ItemRepository(List<Item> items) {
        this.items = items;
    }

    private void initItems() {
        this.items = new ArrayList<>();
        items.add(new Item(1L,ItemType.T_SHIRT,10,20));
        items.add(new Item(2L,ItemType.SCOTCH_BOTTLE,2,40));
        items.add(new Item(3L,ItemType.BEER,5,7));
        items.add(new Item(4L,ItemType.BEER,10,7));
        items.add(new Item(5L,ItemType.BASKETBALL,0,50));
        items.add(new Item(6L,ItemType.LAPTOP,365,500));
        items.add(new Item(7L,ItemType.BANANA,3,2));
    }

    public List<Item> getItems() {
        return items;
    }
}
