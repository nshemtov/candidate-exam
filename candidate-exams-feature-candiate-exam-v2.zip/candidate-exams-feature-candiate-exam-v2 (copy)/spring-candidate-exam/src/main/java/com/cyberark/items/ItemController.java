package com.cyberark.items;

import com.cyberark.items.entities.Item;
import com.cyberark.items.entities.ItemRuleType;
import com.cyberark.items.entities.ItemType;
import com.cyberark.items.services.ItemService;
import com.cyberark.items.services.RuleHandler;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.NoSuchElementException;

@RestController
public class ItemController {

    @Autowired
    private ItemService itemService;
    @Autowired
    private RuleHandler ruleHandler;

    @GetMapping(path = "/api/items")
    public ResponseEntity<List<Item>> findAllItems() {
        return ResponseEntity.ok(itemService.getItems());
    }

    @GetMapping(path = "/api/items/{id}")
    public ResponseEntity<Item> getItem(@PathVariable(name = "id") Long itemId) {
        Item item;
        try {
            item = itemService.getItem(itemId);
        }
        catch(NoSuchElementException e) {
            return ResponseEntity.notFound().build();
        }
        return ResponseEntity.ok(item);
    }

    @PostMapping(path = "/api/items")
    @ResponseBody
    public ResponseEntity<Item> createItem(@RequestBody Item item) {
        itemService.addItem(item);
        return new ResponseEntity(item, HttpStatus.CREATED);
    }

    @PutMapping(path = "/api/items/dailyUpdate")
    @ResponseBody
    public ResponseEntity<Void> dailyUpdate() {
        itemService.dailyUpdateItems();
        return new ResponseEntity(HttpStatus.OK);
    }

    @PutMapping(path = "/api/items/rules")
    @ResponseBody
    public ResponseEntity<Void> setItemRule(@RequestParam ItemType itemType, @RequestParam ItemRuleType itemRuleType) {
        ruleHandler.setItemTypeRule(itemType, itemRuleType);
        return new ResponseEntity(HttpStatus.OK);
    }
}